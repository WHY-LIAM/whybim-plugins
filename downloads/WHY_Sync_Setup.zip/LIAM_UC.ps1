# UTF-8 Encoding with BOM
# WH BimBoxSyncTool 雙向同步外掛 ─ 一鍵卸載助手

Clear-Host
$Host.UI.RawUI.WindowTitle = "WH BimBoxSyncTool 一鍵卸載助手"

# 設定編碼為 UTF-8 確保中文字元顯示正常
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "==========================================================================" -ForegroundColor Red
Write-Host "          WH BimBoxSyncTool (Revit & Navisworks) 雙向同步外掛" -ForegroundColor Red
Write-Host "                         一 鍵 卸 載 助 手" -ForegroundColor Red
Write-Host "==========================================================================" -ForegroundColor Red
Write-Host ""
Write-Host "本助手將自動偵測並移除您電腦中所有的 WH BimBoxSyncTool 外掛檔案。" -ForegroundColor Gray
Write-Host ""

$confirm = Read-Host "確定要開始卸載嗎？ (Y/N)"
if ($confirm -notmatch "^[Yy]$") {
    Write-Host "已取消卸載。" -ForegroundColor Yellow
    Write-Host "按任意鍵關閉視窗..." -ForegroundColor Gray
    [void][System.Console]::ReadKey()
    exit
}

Write-Host ""
Write-Host "正在進行卸載程序..." -ForegroundColor Cyan
Write-Host ""

$removedCount = 0

# ------------------------------------------------------------------------
# 1. 移除 Revit 外掛
# ------------------------------------------------------------------------
Write-Host "正在搜尋 Revit 外掛..." -ForegroundColor Yellow

$revitPaths = @(
    "$env:APPDATA\Autodesk\Revit\Addins",
    "$env:ProgramData\Autodesk\Revit\Addins"
)

foreach ($basePath in $revitPaths) {
    if (Test-Path $basePath) {
        # 尋找所有年份子資料夾
        $years = Get-ChildItem -Path $basePath -Directory
        foreach ($year in $years) {
            $addinFile = Join-Path $year.FullName "BimBoxSyncTool.addin"
            $dllFile = Join-Path $year.FullName "BimBoxSyncTool.dll"
            
            if (Test-Path $addinFile) {
                try {
                    Remove-Item -Path $addinFile -Force
                    Write-Host "  [已移除] Revit $($year.Name) 增益集清單檔案 (.addin)" -ForegroundColor Green
                    $removedCount++
                } catch {
                    Write-Host "  [失敗] 無法移除：$addinFile (請確認 Revit 是否已關閉)" -ForegroundColor Red
                }
            }
            if (Test-Path $dllFile) {
                try {
                    Remove-Item -Path $dllFile -Force
                    Write-Host "  [已移除] Revit $($year.Name) 外掛主程式 (.dll)" -ForegroundColor Green
                    $removedCount++
                } catch {
                    Write-Host "  [失敗] 無法移除：$dllFile (請確認 Revit 是否已關閉)" -ForegroundColor Red
                }
            }
        }
    }
}

# ------------------------------------------------------------------------
# 2. 移除 Navisworks 外掛
# ------------------------------------------------------------------------
Write-Host ""
Write-Host "正在搜尋 Navisworks 外掛..." -ForegroundColor Yellow

$navisPaths = @(
    "$env:APPDATA\Autodesk\Navisworks Manage *",
    "$env:ProgramData\Autodesk\Autodesk Navisworks Manage *",
    "$env:ProgramData\Autodesk\Navisworks Manage *"
)

# 展開萬用字元目錄
$resolvedNavisPaths = @()
foreach ($p in $navisPaths) {
    if (Test-Path (Split-Path $p)) {
        $resolvedNavisPaths += Resolve-Path $p -ErrorAction SilentlyContinue
    }
}

foreach ($navPath in $resolvedNavisPaths) {
    $pluginsDir = Join-Path $navPath.Path "Plugins"
    if (Test-Path $pluginsDir) {
        $v1Folder = Join-Path $pluginsDir "NavisSyncScopeBox"
        $v2Folder = Join-Path $pluginsDir "NavisSyncScopeBoxV2"

        if (Test-Path $v1Folder) {
            try {
                Remove-Item -Path $v1Folder -Recurse -Force
                Write-Host "  [已移除] Navisworks V1 插件資料夾：$v1Folder" -ForegroundColor Green
                $removedCount++
            } catch {
                Write-Host "  [失敗] 無法移除：$v1Folder (請確認 Navisworks 是否已關閉)" -ForegroundColor Red
            }
        }

        if (Test-Path $v2Folder) {
            try {
                Remove-Item -Path $v2Folder -Recurse -Force
                Write-Host "  [已移除] Navisworks V2 插件資料夾：$v2Folder" -ForegroundColor Green
                $removedCount++
            } catch {
                Write-Host "  [失敗] 無法移除：$v2Folder (請確認 Navisworks 是否已關閉)" -ForegroundColor Red
            }
        }
    }
}

# ------------------------------------------------------------------------
# 3. 移除暫存與設定資料夾
# ------------------------------------------------------------------------
Write-Host ""
Write-Host "正在清理快取與設定..." -ForegroundColor Yellow

$configFolder = "$env:APPDATA\BimBoxSyncTool"
if (Test-Path $configFolder) {
    try {
        Remove-Item -Path $configFolder -Recurse -Force
        Write-Host "  [已移除] 外掛設定檔與快取資料夾：$configFolder" -ForegroundColor Green
        $removedCount++
    } catch {
        Write-Host "  [提示] 無法移除部分設定檔，這不影響外掛移除主體。" -ForegroundColor DarkGray
    }
}

# ------------------------------------------------------------------------
# 結束提示
# ------------------------------------------------------------------------
Write-Host ""
Write-Host "==========================================================================" -ForegroundColor Red
if ($removedCount -gt 0) {
    Write-Host "  一鍵卸載已完成！外掛檔案已成功從您的系統中移除。" -ForegroundColor Green
} else {
    Write-Host "  未在系統中發現任何已安裝的外掛檔案。" -ForegroundColor Yellow
}
Write-Host "==========================================================================" -ForegroundColor Red
Write-Host ""
Write-Host "按任意鍵關閉視窗..." -ForegroundColor Gray
[void][System.Console]::ReadKey()
