# UTF-8 Encoding with BOM
# WH BimBoxSyncTool 雙向同步外掛 ─ 一鍵安裝助手

Clear-Host
$Host.UI.RawUI.WindowTitle = "WH BimBoxSyncTool 一鍵安裝助手"

# 設定編碼為 UTF-8 確保中文字元顯示正常
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host "          WH BimBoxSyncTool (Revit & Navisworks) 雙向同步外掛" -ForegroundColor Cyan
Write-Host "                         一 鍵 安 裝 助 手" -ForegroundColor Cyan
Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "本助手將引導您完成外掛安裝，無須管理員權限即可快速完成安裝。" -ForegroundColor Gray
Write-Host ""

# ------------------------------------------------------------------------
# 步驟 1: 安裝 Revit 外掛
# ------------------------------------------------------------------------
Write-Host "--------------------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "【步驟 1/2】安裝 Revit 外掛" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "常見的 Revit 版本年份：2022, 2023, 2024, 2025" -ForegroundColor Gray
$revitVer = Read-Host "請輸入您的 Revit 版本年份 (例如 2022，輸入 0 則跳過此安裝)"

if ($revitVer -ne "0" -and $revitVer -match "^\d{4}$") {
    $revitDest = "$env:APPDATA\Autodesk\Revit\Addins\$revitVer"
    
    # 建立目標資料夾（如果不存在）
    if (!(Test-Path $revitDest)) {
        New-Item -ItemType Directory -Path $revitDest -Force | Out-Null
    }
    
    # 複製檔案
    try {
        Copy-Item -Path ".\1. Revit 2022 外掛安裝\BimBoxSyncTool.addin" -Destination "$revitDest\" -Force
        Copy-Item -Path ".\1. Revit 2022 外掛安裝\BimBoxSyncTool.dll" -Destination "$revitDest\" -Force
        Write-Host "  [成功] 已成功將 Revit 外掛檔案拷貝至：$revitDest" -ForegroundColor Green
    }
    catch {
        Write-Host "  [失敗] 檔案拷貝失敗，請確認是否解壓縮檔案後再執行。錯誤資訊：$($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "  [跳過] 已跳過 Revit 外掛安裝或輸入無效。" -ForegroundColor DarkGray
}
Write-Host ""

# ------------------------------------------------------------------------
# 步驟 2: 安裝 Navisworks 外掛
# ------------------------------------------------------------------------
Write-Host "--------------------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "【步驟 2/2】安裝 Navisworks Manage 外掛" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "常見的 Navisworks Manage 版本年份：2024, 2025, 2026" -ForegroundColor Gray
$navisVer = Read-Host "請輸入您的 Navisworks Manage 版本年份 (例如 2026，輸入 0 則跳過此安裝)"

if ($navisVer -ne "0" -and $navisVer -match "^\d{4}$") {
    $navisDest = "$env:APPDATA\Autodesk\Navisworks Manage $navisVer\Plugins"
    
    Write-Host ""
    Write-Host "請選擇您要安裝的 Navisworks 外掛功能版本：" -ForegroundColor Cyan
    Write-Host "  [1] 柱位精準定位 V1 (標準版：單一柱號交點定位)" -ForegroundColor White
    Write-Host "  [2] 柱位區間定位 V2 (進階版：支援 A~D 柱、2~4 軸大範圍定位與外擴)" -ForegroundColor White
    Write-Host "  [3] 兩者皆安裝 (推薦！增益集分頁將同時呈現 V1 與 V2 按鈕)" -ForegroundColor Green
    $opt = Read-Host "請輸入選擇編號 [1-3]"

    $installV1 = $false
    $installV2 = $false

    if ($opt -eq "1") {
        $installV1 = $true
    } elseif ($opt -eq "2") {
        $installV2 = $true
    } elseif ($opt -eq "3" -or $null -eq $opt -or $opt -eq "") {
        $installV1 = $true
        $installV2 = $true
    } else {
        Write-Host "  [警告] 輸入無效，預設為您安裝兩者皆包含的完整版本！" -ForegroundColor Yellow
        $installV1 = $true
        $installV2 = $true
    }

    # 1. 部署 V1 Standard
    if ($installV1) {
        $navisPluginDirV1 = "$navisDest\NavisSyncScopeBox"
        if (!(Test-Path $navisPluginDirV1)) {
            New-Item -ItemType Directory -Path $navisPluginDirV1 -Force | Out-Null
        }
        try {
            Copy-Item -Path ".\2. Navisworks 2026 外掛安裝\NavisSyncScopeBox\NavisSyncScopeBox.dll" -Destination "$navisPluginDirV1\" -Force
            Write-Host "  [成功] 已將 V1 (標準版) 檔案拷貝至：$navisPluginDirV1" -ForegroundColor Green
        }
        catch {
            Write-Host "  [失敗] V1 檔案拷貝失敗！錯誤資訊：$($_.Exception.Message)" -ForegroundColor Red
        }
    }

    # 2. 部署 V2 Advanced
    if ($installV2) {
        $navisPluginDirV2 = "$navisDest\NavisSyncScopeBoxV2"
        if (!(Test-Path $navisPluginDirV2)) {
            New-Item -ItemType Directory -Path $navisPluginDirV2 -Force | Out-Null
        }
        try {
            Copy-Item -Path ".\2. Navisworks 2026 外掛安裝\NavisSyncScopeBoxV2\NavisSyncScopeBoxV2.dll" -Destination "$navisPluginDirV2\" -Force
            Write-Host "  [成功] 已將 V2 (進階版) 檔案拷貝至：$navisPluginDirV2" -ForegroundColor Green
        }
        catch {
            Write-Host "  [失敗] V2 檔案拷貝失敗！請確認是否解壓縮檔案後再執行。錯誤資訊：$($_.Exception.Message)" -ForegroundColor Red
        }
    }

} else {
    Write-Host "  [跳過] 已跳過 Navisworks 外掛安裝或輸入無效。" -ForegroundColor DarkGray
}
Write-Host ""

# ------------------------------------------------------------------------
# 完成提示
# ------------------------------------------------------------------------
Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host "  一鍵安裝程序已全部執行完畢！" -ForegroundColor Green
Write-Host "  請重新啟動 Revit 及 Navisworks 載入全新的「WH 雙向範圍框同步工具」！" -ForegroundColor Green
Write-Host "==========================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "按任意鍵關閉視窗..." -ForegroundColor Gray
[void][System.Console]::ReadKey()

